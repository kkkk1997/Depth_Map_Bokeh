% demo for addCartoon(img0,DB_fullMP)
% img0 is the original input image
% DB_fullMP is full map of defocus map
% Need bfilter2o.m in the same folder
clc; clear; close all;
img0 = imread('Test image 3_flower.png');
DB_fullMP = imread('Test image 3_DMap.png');
imgCartoon = addCartoon(img0, DB_fullMP);
imshow(imgCartoon)