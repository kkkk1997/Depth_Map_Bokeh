package com.example.cameraalbumtest;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.ImageView;


public class ResultView{

    public boolean IsShowingResult; //flag for showing result image
    public Bitmap resultImage;
    public ImageView picture;

    public ResultView(Context context) {
        IsShowingResult = false;
    }

    protected void onDraw(){
        if (IsShowingResult)
        {
            picture.setImageBitmap(resultImage);
        }
    }
}
