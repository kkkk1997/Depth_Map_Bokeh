function imgCartoon = addCartoon(img0, DB_fullMP)

% img0 is the original input image
% DB_fullMP is full map of defocus map

% blend colorful image with edge
% img0 = imread('Test image 4_person.png');
img = rgb2gray(img0);
% imshow(img0);
% normalize to [0 1]
img0_norm(:,:,1) = img0(:,:,1) - min(min(img0(:,:,1)));
img0_norm2(:,:,1) = double(img0_norm(:,:,1)) ./ double(max(max(img0_norm(:,:,1))));
%imshow(img0_norm2(:,:,1),[])
img0_norm(:,:,2) = img0(:,:,2) - min(min(img0(:,:,2)));
img0_norm2(:,:,2) = double(img0_norm(:,:,2)) ./ double(max(max(img0_norm(:,:,2))));
%imshow(img0_norm2(:,:,2),[])
img0_norm(:,:,3) = img0(:,:,3) - min(min(img0(:,:,3)));
img0_norm2(:,:,3) = double(img0_norm(:,:,3)) ./ double(max(max(img0_norm(:,:,3))));

% Apply bilateral filter to get smooth image
W = 10;
sigmab = [30 0.1];
imgbi = bfilter2o(img0_norm2,W,sigmab);
% figure();
% imshow(imgbi);
imgbi = uint8(imgbi*255);
% imagesc(imgbi)

% Detect canny edge
sigmaArray = 1;
thresh = 0.1;
% figure(1), clf;
% subplot(1, 2, 1), imshow(img); title('original image');
sigma = sigmaArray;
imgEdge = edge(img, 'canny', thresh, sigma);
% subplot(1, 2, 2), imshow(imgEdge); title('Edges');

% combine image with edge
imgbi1 = imgbi;
thr = 200;
for m=1:size(imgbi1,1)
    for n=1:size(imgbi1,2)
        if(imgEdge(m,n)==1) % operate on edges
           imgbi1(m,n,1)=img0(m,n,1)-thr;
           imgbi1(m,n,2)=img0(m,n,2)-thr;
           imgbi1(m,n,3)=img0(m,n,3)-thr;
        end
    end
end
% figure()
% imshow(imgbi1);

% combined with defocus map
% DB_fullMP = imread('Test image 4_DMap.png');% based on the ground truth
DBdouble = double(DB_fullMP);

% foreground/background segamentation
maxDBdouble = max(DBdouble(:));
minDBdouble = min(DBdouble(:));
BW_DB = im2bw(DB_fullMP,(maxDBdouble - mean(DBdouble(:)))/(maxDBdouble - minDBdouble));
% imshow(BW_DB);

% Get edges of BW_DB
se1 = strel('square',3);
se2 = strel('square',6);
erodedBW = imerode(BW_DB,se1);
dilateBW1 = imdilate(BW_DB,se1);
dilateBW2 = imdilate(BW_DB,se2);
edgeBW = dilateBW2 - dilateBW1;

% Add catoon effect on the foreground
offset = 40;
imgbi2 = imgbi1;
for m=1:size(imgbi2,1)
    for n=1:size(imgbi2,2)
        if(BW_DB(m,n)==1) % operate on background
           imgbi2(m,n,1)=img0(m,n,1)+offset;
           imgbi2(m,n,2)=img0(m,n,2)+offset;
           imgbi2(m,n,3)=img0(m,n,3)+offset;
        end
        if(edgeBW(m,n) == 1)
           imgbi2(m,n,1)=0;
           imgbi2(m,n,2)=0;
           imgbi2(m,n,3)=0;
        end
    end
end
% figure()
% imshow(imgbi2);
imgCartoon = imgbi2;

% Quantize color
% [imgQ,map] = rgb2ind(imgbi2,16,'nodither');
% figure('Name','Indexed image with 32 Colors')
% imshow(imgQ,map);
