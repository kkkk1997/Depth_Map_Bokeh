
DB_edge_BF = bfilter2(DB_edge_norm2,W,sigmab);